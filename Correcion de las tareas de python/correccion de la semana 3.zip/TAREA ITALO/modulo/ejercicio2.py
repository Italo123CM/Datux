def por_dos(x):
    return x*2+(suma(x))

def suma(x):
    return x+3
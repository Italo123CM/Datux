def SumaN(n):
    if(n==1):
        return 1
    else:
        return n+SumaN(n-1)

def div(n1,n2):
    return n1/n2
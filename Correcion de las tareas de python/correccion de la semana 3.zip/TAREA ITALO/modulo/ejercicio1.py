def texto_split(texto):
    print(texto.split(" "))

def texto_join(texto):
    print(" ".join(texto))

def texto_count(texto):
    print(texto.count("i"))

def texto_find(texto):
    print(texto.find("unimpresor"))

def texto_upper(texto):
    print(texto.upper())

def texto_lower(texto):
    print(texto.lower())